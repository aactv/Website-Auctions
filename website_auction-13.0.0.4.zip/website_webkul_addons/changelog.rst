# Changelog
All notable changes to this project will be documented in this file.




## [Unreleased]



##[3.0.0] -2019-08-07
### Changed
-make module compatible with odoo13
-remove the @api.multi decorators
